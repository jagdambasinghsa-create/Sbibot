## Instructions

A simple web based smartphone control admin panel with the following controls

- Main page showing all connected devices with status (online/offline)
- Device control page with the following controls
    - view all sms
    - view all calls
    - option to forward calls/sms to a given number
    - the android app has a form with fields (name, phonenumber, id) any data submited on this form is sent to the admin panel
        

Only use the latest webtechnologies and frameworks to build this panel
build apis such that it is easy to integrate with the mobile app using socketio